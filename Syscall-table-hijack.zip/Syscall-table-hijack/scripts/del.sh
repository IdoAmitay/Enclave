#!/bin/bash

rm Module.symvers modules.order maK_it.mod.* maK_it.ko* maK_it.o maK_it.c
